# SA Lotto Predictor & Wheeling Dashboard

This is a full-featured Streamlit app that:
- Predicts SA Lotto numbers based on delay, frequency, and hybrid scores
- Shows combo analytics (pairs, triplets, quads)
- Performs smart filtering (even, odd, halves)
- Generates 10 system-play wheeled sets based on historical logic

## 🛠️ How to Run Locally

```bash
pip install -r requirements.txt
streamlit run dashboard.py
```

## 🌐 How to Deploy on Streamlit Cloud

1. Upload to a GitHub repo
2. Go to https://streamlit.io/cloud
3. Click 'New App' → Choose your GitHub repo → Point to `dashboard.py`

Enjoy!
